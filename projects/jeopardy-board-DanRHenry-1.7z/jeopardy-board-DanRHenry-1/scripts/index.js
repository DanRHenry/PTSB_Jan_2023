// Do not change the import statement
// This statement imports the exported file so its contents are accedssible o us

// This makes the "placeholderquestions" act like a variable essentially
import placeholderQuestions from "./placeholder-questions.js";
console.log({ placeholderQuestions });
// 
console.log(placeholderQuestions)
console.log(placeholderQuestions[0])
// When I need a question/answer, I can iterate over the array